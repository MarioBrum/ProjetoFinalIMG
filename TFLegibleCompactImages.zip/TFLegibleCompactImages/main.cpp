#include <QApplication>
#include <QImage>
#include <QPainter>
#include <QLabel>
#include <QVBoxLayout>
#include <QFont>

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);

    // Carregando a imagem
    QString caminho_da_imagem = "C:/Users/brum-/OneDrive/Documentos/TFLegibleCompactImages/morcego.jpg";
    QImage imagem(caminho_da_imagem);

    // Verificando se a imagem foi carregada corretamente
    if (imagem.isNull()) {
        qCritical() << "Erro ao carregar a imagem.";
        return -1;
    }

    // Inserindo texto na imagem
    QString texto = "morcego";
    QPainter painter(&imagem);
    painter.setPen(QColor(0, 0, 0));  // Cor preta
    painter.setFont(QFont("Futura Bold", 12)); //Futura Bold
    painter.drawText(10, 30, texto);

    // Criando a interface gráfica com o Qt
    QVBoxLayout layout;
    QLabel label;
    label.setPixmap(QPixmap::fromImage(imagem));
    layout.addWidget(&label);

    // Exibindo a interface gráfica
    QWidget window;
    window.setLayout(&layout);
    window.show();

    return a.exec();
}
